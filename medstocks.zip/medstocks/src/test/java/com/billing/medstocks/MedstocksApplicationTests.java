package com.billing.medstocks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedstocksApplicationTests {

	@Test
	void contextLoads() {
	}

}
