package com.billing.medstocks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedstocksApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedstocksApplication.class, args);
	}

}
